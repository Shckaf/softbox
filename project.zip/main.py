"""Softbox - экранная подсветка / ночник на Kivy."""
import colorsys

from kivy.app import App
from kivy.clock import Clock
from kivy.core.window import Window
from kivy.lang import Builder
from kivy.properties import BooleanProperty, ListProperty, NumericProperty, StringProperty
from kivy.uix.floatlayout import FloatLayout
from kivy.utils import platform

KV = """
#:import dp kivy.metrics.dp

<ModeButton@Button>:
    background_normal: ''
    background_down: ''
    font_size: '16sp'
    bold: True

<ColorSlider@Slider>:
    min: 0
    max: 255
    step: 1

<Root>:
    canvas.before:
        Color:
            rgba: root.light_color
        Rectangle:
            pos: self.pos
            size: self.size

    BoxLayout:
        id: panel
        orientation: 'vertical'
        size_hint: 1, None
        height: dp(400)
        pos: 0, 0
        padding: dp(12)
        spacing: dp(6)
        opacity: 1 if root.ui_visible else 0
        disabled: not root.ui_visible
        canvas.before:
            Color:
                rgba: 0, 0, 0, 0.65
            Rectangle:
                pos: self.pos
                size: self.size

        BoxLayout:
            size_hint_y: None
            height: dp(32)
            Label:
                text: 'R'
                size_hint_x: None
                width: dp(28)
                color: 1, 0.4, 0.4, 1
            ColorSlider:
                disabled: root.mode == 'rainbow'
                value: root.r
                on_value: root.r = self.value
            Label:
                text: str(int(root.r))
                size_hint_x: None
                width: dp(40)

        BoxLayout:
            size_hint_y: None
            height: dp(32)
            Label:
                text: 'G'
                size_hint_x: None
                width: dp(28)
                color: 0.4, 1, 0.4, 1
            ColorSlider:
                disabled: root.mode == 'rainbow'
                value: root.g
                on_value: root.g = self.value
            Label:
                text: str(int(root.g))
                size_hint_x: None
                width: dp(40)

        BoxLayout:
            size_hint_y: None
            height: dp(32)
            Label:
                text: 'B'
                size_hint_x: None
                width: dp(28)
                color: 0.4, 0.6, 1, 1
            ColorSlider:
                disabled: root.mode == 'rainbow'
                value: root.b
                on_value: root.b = self.value
            Label:
                text: str(int(root.b))
                size_hint_x: None
                width: dp(40)

        BoxLayout:
            size_hint_y: None
            height: dp(32)
            Label:
                text: 'Скор.'
                size_hint_x: None
                width: dp(52)
            Slider:
                min: 1
                max: 15
                step: 1
                value: root.speed
                on_value: root.speed = self.value
            Label:
                text: str(int(root.speed))
                size_hint_x: None
                width: dp(40)

        BoxLayout:
            size_hint_y: None
            height: dp(56)
            spacing: dp(6)
            ModeButton:
                text: 'Постоянный'
                background_color: (0.2, 0.6, 0.9, 1) if root.mode == 'static' else (0.3, 0.3, 0.3, 1)
                on_release: root.set_mode('static')
            ModeButton:
                text: 'Стробоскоп'
                background_color: (0.2, 0.6, 0.9, 1) if root.mode == 'strobe' else (0.3, 0.3, 0.3, 1)
                on_release: root.set_mode('strobe')
            ModeButton:
                text: 'Радуга'
                background_color: (0.2, 0.6, 0.9, 1) if root.mode == 'rainbow' else (0.3, 0.3, 0.3, 1)
                on_release: root.set_mode('rainbow')

        ModeButton:
            text: 'Скрыть интерфейс (тап по экрану вернёт панель)'
            size_hint_y: None
            height: dp(56)
            background_color: 0.15, 0.15, 0.15, 1
            on_release: root.ui_visible = False
"""


class Root(FloatLayout):
    r = NumericProperty(255)
    g = NumericProperty(214)
    b = NumericProperty(170)
    speed = NumericProperty(3)
    mode = StringProperty("static")
    ui_visible = BooleanProperty(True)
    light_color = ListProperty([1, 0.84, 0.67, 1])

    _phase = 0.0
    _hue = 0.0
    _strobe_on = True

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.bind(r=self.refresh, g=self.refresh, b=self.refresh)
        self.refresh()
        Clock.schedule_interval(self.tick, 1 / 60.0)

    def set_mode(self, mode):
        self.mode = mode
        self._phase = 0.0
        self._strobe_on = True
        if mode == "rainbow":
            h, _, _ = colorsys.rgb_to_hsv(self.r / 255, self.g / 255, self.b / 255)
            self._hue = h
        self.refresh()

    def refresh(self, *args):
        if self.mode == "strobe" and not self._strobe_on:
            self.light_color = [0, 0, 0, 1]
        else:
            self.light_color = [self.r / 255.0, self.g / 255.0, self.b / 255.0, 1]

    def tick(self, dt):
        if self.mode == "rainbow":
            self._hue = (self._hue + dt * self.speed * 0.05) % 1.0
            rr, gg, bb = colorsys.hsv_to_rgb(self._hue, 1, 1)
            self.r, self.g, self.b = rr * 255, gg * 255, bb * 255
        elif self.mode == "strobe":
            self._phase = (self._phase + dt * self.speed) % 1.0
            on = self._phase < 0.5
            if on != self._strobe_on:
                self._strobe_on = on
                self.refresh()

    def on_touch_down(self, touch):
        if not self.ui_visible:
            self.ui_visible = True
            return True
        return super().on_touch_down(touch)


def keep_screen_awake():
    """Не даём экрану гаснуть и ставим максимальную яркость окна."""
    Window.allow_screensaver = False
    if platform != "android":
        return
    try:
        from android.runnable import run_on_ui_thread
        from jnius import autoclass

        @run_on_ui_thread
        def apply():
            activity = autoclass("org.kivy.android.PythonActivity").mActivity
            params_cls = autoclass("android.view.WindowManager$LayoutParams")
            window = activity.getWindow()
            window.addFlags(params_cls.FLAG_KEEP_SCREEN_ON)
            attrs = window.getAttributes()
            attrs.screenBrightness = 1.0
            window.setAttributes(attrs)

        apply()
    except Exception as exc:  # noqa: BLE001
        print("keep_screen_awake failed:", exc)


class SoftboxApp(App):
    title = "Softbox"

    def build(self):
        Builder.load_string(KV)
        return Root()

    def on_start(self):
        keep_screen_awake()

    def on_pause(self):
        return True

    def on_resume(self):
        keep_screen_awake()


if __name__ == "__main__":
    SoftboxApp().run()
