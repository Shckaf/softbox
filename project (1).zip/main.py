"""Camglow - тест управления световым кольцом камеры через светодиодный индикатор уведомлений."""
from kivy.app import App
from kivy.lang import Builder
from kivy.properties import NumericProperty, StringProperty
from kivy.uix.boxlayout import BoxLayout
from kivy.utils import platform

NOTIF_ID = 4242
_state = {"channel": None}

KV = """
#:import dp kivy.metrics.dp

<ColorSlider@Slider>:
    min: 0
    max: 255
    step: 1

<Root>:
    orientation: 'vertical'
    padding: dp(16)
    spacing: dp(10)

    Label:
        text: 'Camglow: тест кольца камеры'
        font_size: '20sp'
        bold: True
        size_hint_y: None
        height: dp(40)

    Widget:
        size_hint_y: None
        height: dp(60)
        canvas:
            Color:
                rgb: root.r / 255., root.g / 255., root.b / 255.
            RoundedRectangle:
                pos: self.pos
                size: self.size
                radius: [dp(12)]

    BoxLayout:
        size_hint_y: None
        height: dp(40)
        Label:
            text: 'R'
            size_hint_x: None
            width: dp(28)
        ColorSlider:
            value: root.r
            on_value: root.r = self.value
        Label:
            text: str(int(root.r))
            size_hint_x: None
            width: dp(40)

    BoxLayout:
        size_hint_y: None
        height: dp(40)
        Label:
            text: 'G'
            size_hint_x: None
            width: dp(28)
        ColorSlider:
            value: root.g
            on_value: root.g = self.value
        Label:
            text: str(int(root.g))
            size_hint_x: None
            width: dp(40)

    BoxLayout:
        size_hint_y: None
        height: dp(40)
        Label:
            text: 'B'
            size_hint_x: None
            width: dp(28)
        ColorSlider:
            value: root.b
            on_value: root.b = self.value
        Label:
            text: str(int(root.b))
            size_hint_x: None
            width: dp(40)

    BoxLayout:
        size_hint_y: None
        height: dp(56)
        spacing: dp(8)
        Button:
            text: 'ВКЛЮЧИТЬ'
            on_release: root.turn_on()
        Button:
            text: 'ВЫКЛЮЧИТЬ'
            on_release: root.turn_off()

    Button:
        text: 'Настройки уведомлений приложения'
        size_hint_y: None
        height: dp(48)
        on_release: root.open_settings()

    Label:
        text: root.status
        size_hint_y: None
        text_size: self.width, None
        height: self.texture_size[1] + dp(8)
        halign: 'left'

    Label:
        text: 'Как проверять: нажмите ВКЛЮЧИТЬ, разрешите уведомления, затем выключите экран кнопкой питания и посмотрите на кольцо. Эффект для приложения Camglow можно выбрать в системных настройках подсветки камеры.'
        font_size: '13sp'
        color: 0.8, 0.8, 0.8, 1
        text_size: self.width, None
        halign: 'left'
        valign: 'top'
"""


def _java():
    from jnius import autoclass, cast

    activity = autoclass("org.kivy.android.PythonActivity").mActivity
    context = autoclass("android.content.Context")
    nm = cast(
        "android.app.NotificationManager",
        activity.getSystemService(context.NOTIFICATION_SERVICE),
    )
    return activity, nm


def _cs(text):
    from jnius import autoclass, cast

    return cast("java.lang.CharSequence", autoclass("java.lang.String")(text))


class Root(BoxLayout):
    r = NumericProperty(0)
    g = NumericProperty(255)
    b = NumericProperty(120)
    status = StringProperty("Готово.")

    def turn_on(self):
        if platform != "android":
            self.status = "Работает только на Android."
            return
        try:
            from jnius import autoclass

            activity, nm = _java()
            channel_cls = autoclass("android.app.NotificationChannel")
            manager_cls = autoclass("android.app.NotificationManager")
            builder_cls = autoclass("android.app.Notification$Builder")
            color_cls = autoclass("android.graphics.Color")

            r, g, b = int(self.r), int(self.g), int(self.b)
            channel_id = "glow_%02x%02x%02x" % (r, g, b)

            channel = channel_cls(channel_id, _cs("Camglow %02x%02x%02x" % (r, g, b)),
                                  manager_cls.IMPORTANCE_DEFAULT)
            channel.enableLights(True)
            channel.setLightColor(color_cls.rgb(r, g, b))
            channel.enableVibration(False)
            try:
                channel.setSound(None, None)
            except Exception as exc:  # noqa: BLE001
                print("setSound failed:", exc)
            nm.createNotificationChannel(channel)

            builder = builder_cls(activity, channel_id)
            builder.setContentTitle(_cs("Camglow включён"))
            builder.setContentText(_cs("Цвет R%d G%d B%d" % (r, g, b)))
            builder.setSmallIcon(activity.getApplicationInfo().icon)
            builder.setOngoing(True)
            nm.notify(NOTIF_ID, builder.build())

            old = _state["channel"]
            if old and old != channel_id:
                try:
                    nm.deleteNotificationChannel(old)
                except Exception as exc:  # noqa: BLE001
                    print("delete channel failed:", exc)
            _state["channel"] = channel_id
            self.status = "Уведомление отправлено (цвет %d, %d, %d). Выключите экран и проверьте кольцо." % (r, g, b)
        except Exception as exc:  # noqa: BLE001
            self.status = "Ошибка: %s" % exc

    def turn_off(self):
        if platform != "android":
            return
        try:
            _, nm = _java()
            nm.cancel(NOTIF_ID)
            self.status = "Уведомление убрано."
        except Exception as exc:  # noqa: BLE001
            self.status = "Ошибка: %s" % exc

    def open_settings(self):
        if platform != "android":
            return
        try:
            from jnius import autoclass

            activity, _ = _java()
            intent_cls = autoclass("android.content.Intent")
            settings_cls = autoclass("android.provider.Settings")
            intent = intent_cls(settings_cls.ACTION_APP_NOTIFICATION_SETTINGS)
            intent.putExtra(settings_cls.EXTRA_APP_PACKAGE, activity.getPackageName())
            activity.startActivity(intent)
        except Exception as exc:  # noqa: BLE001
            self.status = "Ошибка: %s" % exc


class CamglowApp(App):
    title = "Camglow"

    def build(self):
        Builder.load_string(KV)
        return Root()

    def on_start(self):
        if platform == "android":
            try:
                from android.permissions import request_permissions

                request_permissions(["android.permission.POST_NOTIFICATIONS"])
            except Exception as exc:  # noqa: BLE001
                print("permission request failed:", exc)

    def on_pause(self):
        return True


if __name__ == "__main__":
    CamglowApp().run()
